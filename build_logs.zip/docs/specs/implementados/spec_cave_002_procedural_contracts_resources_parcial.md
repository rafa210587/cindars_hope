# SPEC CAVE-002 - Procedural contracts e resources parcial

> Status: Implementado parcial
> Camada: Cave
> Fonte historica: `docs_old/FASE9F_CAVE_RESOURCES_ENCOUNTERS_SPEC_v1.0.md; docs/refinements/implementados/ref_cave_procedural_runtime_pr141_153.md`
> Evidencia principal: `Assets/_Game/Scripts/Cave/Generation/**`

---

## 1. /speckit.specify

### O que existe
Contratos, generator, runtime materializer e resource nodes existem em codigo para Cave procedural MVP.

A branch historica `feature/docs-fase9f-cave-stable-run-spec` reforcava que a cave procedural substitui a Cave MVP fixa por niveis grandes, reprodutiveis e exploraveis, com contratos de geracao, config, pontos de geracao, recursos e materializacao runtime.

### Por que existe
Esta capacidade sustenta o loop jogavel atual de Cindar's Hope e normaliza, em uma spec ativa, o que ja esta implementado ou parcialmente implementado no repositorio.

### Fora de escopo
Nao tratar como implementado final qualquer item listado como pendente, qualquer UX/arte/balanceamento final nao validado ou qualquer sistema futuro ainda sem spec propria.

---

## 2. /speckit.plan

### Arquitetura real
A arquitetura real e composta pelos arquivos listados na evidencia, pelos dados preservados em `docs_old/` e pelo status operacional registrado em `PROJECT_LOG.md`.

Detalhamento absorvido da branch historica:

- `CaveProceduralGenerator` gera layout e pontos de interesse.
- `CaveGeneratedLevel` representa o resultado gerado.
- `CaveRuntimeMaterializer` materializa layout, inimigos, recursos e portais.
- `ResourceNodeDataSO` e `ResourceNode` implementam recursos mineraveis/coletaveis.
- `CaveRunManager` mantem seeds e estado runtime.

### Fluxo
O fluxo operacional segue o MVP atual: sistemas runtime consultam managers/dados por IDs, publicam eventos simples quando aplicavel e expoem estado para HUD, save ou validadores conforme o sistema.

### Persistencia
Quando ha persistencia, ela deve usar DTOs simples e IDs estaveis. Referencias Unity permanecem fora dos DTOs. Quando nao ha persistencia propria, o estado e derivado de managers ou dados ScriptableObject.

---

## 3. /speckit.tasks

### Implementado
- [x] Evidencia principal existe no repo.
- [x] Estado foi registrado ou reconciliado em `PROJECT_LOG.md` e/ou `docs_old/IMPLEMENTATION_STATUS.md`.
- [x] Conteudo historico antigo foi preservado em `docs_old/`.
- [x] Contratos de geracao procedural.
- [x] Configuracao de geracao.
- [x] Resultado gerado com layout e pontos.
- [x] Runtime materializer.
- [x] ResourceNode e tool checks parciais.
- [x] Save parcial de depleted nodes.

### Implementado parcial
- [ ] Validacao Unity Play Mode completa pode estar pendente conforme a area.
- [ ] UX final, arte final, balanceamento final ou cobertura completa so contam quando houver spec e validacao propria.

### Pendente/futuro
- [ ] Balance final de layouts.
- [ ] Loot/scaling completo.
- [ ] Biomas completos.
- [ ] Resource distribution final por level/faixa.
- [ ] Loot tables, bioma progressivo, enemy spawn final e validacao Unity pendentes.

---

## 4. Evidencia no repo

| Tipo | Caminho | Observacao |
|---|---|---|
| Codigo | `Assets/_Game/Scripts/Cave/Generation/**` | Evidencia principal da capacidade. |
| Codigo | `Assets/_Game/Scripts/Cave/Resources/**` | Evidencia principal da capacidade. |
| Codigo | `Assets/_Game/Scripts/Cave/Runtime/CaveRuntimeMaterializer.cs` | Evidencia principal da capacidade. |
| Codigo | `Assets/_Game/Scripts/Cave/Data/ResourceNodeDataSO.cs` | Evidencia principal da capacidade. |
| Historico | `PROJECT_LOG.md` | Log operacional e decisoes recentes. |
| Status antigo | `docs_old/IMPLEMENTATION_STATUS.md` | Tracking anterior preservado. |

---

## 5. Refinamentos relacionados

- `docs/refinements/implementados/ref_implementados_map.md`
- `docs/refinements/a_implementar/ref_futuro_map.md`
- `docs_old/FASE9F_CAVE_RESOURCES_ENCOUNTERS_SPEC_v1.0.md; docs/refinements/implementados/ref_cave_procedural_runtime_pr141_153.md`

---

## 6. Pendencias e riscos

- Loot tables, bioma progressivo, enemy spawn final e validacao Unity pendentes.
- Se a implementacao for parcial, nao promover para final sem evidencia de Unity e sem atualizar esta spec ou criar amendment/correction.
