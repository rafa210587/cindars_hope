# SPEC — Partner Helper Companion Bridge Future Runtime

> **Spec ID:** `17_spec_partner_helper_companion_bridge_future_runtime`  
> **Status:** A implementar / Future mapped  
> **Wave:** WAVE 17 — Social Relationship / Gifts / Partner Helper Future  
> **Priority:** P2  
> **Type:** Runtime / Future / Partner Helper / Companion Bridge  
> **Domain:** Partner Helper / Partner Companion Eligibility / Farm Help / Cave Cap Compatibility  
> **Parallelizable:** NO  
> **Parallel group:** WAVE_17_SOCIAL_RELATIONSHIP_FUTURE  
> **Can run with:** N/A  
> **Must not run with:** qualquer spec que altere companion AI/jobs/combat, farm automation core, romance scenes, marriage ceremony, pet runtime, economy final, save migration or UI visual final.  
> **Repo lock scope:** `Assets/_Game/Scripts/Social/**`, `Assets/_Game/Scripts/Companions/**`, `Assets/_Game/Scripts/Farm/**`, `Assets/_Game/Tests/EditMode/Social/**`, `docs/validation/17_spec_partner_helper_companion_bridge_future_runtime_execution_report.md`  
> **Depends on:**  
  - `docs/design/SPEC_SOURCE_MAP.md`
  - `docs/design/SPECIFICATION_PROCESS.md`
  - `docs/design/lore/VAALARA_GAME_CANON_DIRECTION_v1.0.md`
  - `docs/specs/SPEC_IMPLEMENTABLE_TEMPLATE.md`
  - `docs/specs/SPEC_WAVE_EXECUTION_PROTOCOL.md`
  - `docs/specs/SPEC_VALIDATION_MATRIX_MASTER.md`
  - `docs/specs/SPEC_EXISTING_IMPLEMENTATION_AUDIT.md`
  - `docs/project/CURRENT_STATE.md`
  - `docs/design/gameplay/social/SOCIAL_RELATIONSHIP_ROMANCE_DIRECTION.md`
  - `docs/design/gameplay/city/CITY_DESIGN_DIRECTION_v1.2.md`
  - `docs/design/gameplay/city/CITY_NPC_ROSTER_SERVICES_DIRECTION_v1.1.md`
  - `docs/design/gameplay/city/CITY_LAYOUT_BUILDINGS_SCHEDULE_DIRECTION.md`
  - `docs/design/gameplay/farm/FARM_DESIGN_DIRECTION_v1.3.md`
  - `docs/design/gameplay/farm/FARM_LAYOUT_SCALE_BUILDINGS_DIRECTION.md`
  - `docs/design/gameplay/companions/COMPANIONS_DIRECTION.md`
  - `docs/design/gameplay/pets/PETS_DIRECTION.md`
  - `docs/design/gameplay/loot_crafting_economy/LOOT_CRAFTING_ECONOMY_DIRECTION.md`
  - `docs/design/gameplay/loot_crafting_economy/ECONOMY_PRICING_STOCK_REFRESH_DIRECTION.md`
  - `docs/design/gameplay/quests/QUEST_OBJECTIVE_EVENT_SYSTEM_DIRECTION.md`
  - `docs/design/gameplay/quests/QUESTS_MAIN_LORE_DIRECTION.md`
  - `docs/design/gameplay/quests/QUESTS_MAIN_PROGRESSION_REFINEMENT_DIRECTION.md`
  - `docs/design/gameplay/save_load/SAVE_LOAD_FULL_STATE_DIRECTION.md`
  - `docs/design/gameplay/ui_ux/UI_UX_FULL_GAMEPLAY_DIRECTION.md`
  - `docs/design/gameplay/ui_ux/UI_UX_MENU_SCREEN_FLOWS_DIRECTION.md`
  - `docs/design/gameplay/world/SEASONS_CALENDAR_WEATHER_LUNAR_DIRECTION.md`
  - `docs/design/gameplay/cave/CAVE_DESIGN_DIRECTION.md`
  - `docs/design/gameplay/cave/CAVE_MONSTER_ROSTER_DIRECTION.md`
  - `docs/design/gameplay/bestiary/BESTIARY_KNOWLEDGE_DISCOVERY_DIRECTION.md`
> **Blocks:**  
  - companion eligibility state;
  - farm companion jobs;
  - cave companion assist;
  - partner social state;
  - social UI.
> **Scope:** definir/endurecer bridge futuro entre partner social e companion/helper, sem implementar companion AI, romance scenes ou farm automation final.  
> **Out of scope:** companion AI, cave combat, farm job execution, romance/marriage scenes, pet runtime, economy final.

---

# /speckit.specify

## 1. Contexto

Parceiros românticos/cônjuges podem se tornar companions futuros quando elegíveis. Romance/casamento pode desbloquear rota de companion, mas companion unlock ainda exige perfil e quest apropriada. Ser parceiro não ignora balance de companion, injury/recovery, leash, cave risk ou limites de combate. Mesmo com até 3 parceiros, baseline de caverna continua 1 companion ativo por run.

---

## 2. Problema

Sem bridge seguro:

```text
casar transforma qualquer NPC em combat companion;
3 parceiros entram juntos na caverna;
partner helper substitui farm automation;
benefício de helper vira ouro/stamina infinito;
NPC não combatente vira cave companion;
partner ignora injury/recovery/leash;
romance vira obrigatório para helper forte;
pet é tratado como partner helper.
```

---

## 3. Objetivo

Criar/endurecer:

```text
PartnerHelperEligibility;
PartnerCompanionBridgeRule;
PartnerFarmHelperRule;
PartnerHelperBudget;
PartnerHelperAssignment;
PartnerCompanionUnlockRequest;
PartnerHelperAntiExploitValidator.
```

---

## 4. Regras de design

```text
Partner helper é opcional e limitado.
Ser parceiro não ignora companion eligibility.
NPC não combatente pode ser farm helper sem virar cave companion.
Cave companion cap permanece 1.
Polycule até 3 parceiros não aumenta party size.
Partner helper usa orçamento global para evitar exploit.
Pet não é partner helper.
```

---

## 5. User stories / engineering stories

```text
Como jogador, quero que parceiro elegível possa ajudar de forma limitada.
Como companion, quero manter regras de role/injury/leash/cave risk.
Como farm, quero helper pequeno e bounded.
Como social, quero que helper não vire obrigação romântica.
Como balance, quero impedir helper stacking/exploit.
```

---

## 6. Escopo

Inclui:

```text
bridge rules;
partner helper eligibility;
farm helper limited rules;
companion unlock requests;
budget/cap policies;
anti-exploit tests.
```

Não inclui:

```text
companion AI;
farm job execution;
romance/casamento scenes;
partner moving to farm visuals;
pet runtime;
children/family system.
```

## 7. Modelo de domínio

### 7.1 PartnerHelperEligibility

```text
NpcId
IsPartner
RelationshipKind
PartnerFarmHelperEligible
PartnerCompanionEligible
CanBeFarmHelperNow
CanBeCaveCompanionNow
BlockedReasons[]
```

### 7.2 PartnerCompanionBridgeRule

```text
RuleId
NpcId
RequiresRelationshipStatus
RequiresCompanionEligibility
RequiresPersonalQuestIds[]
RequiresPartnerConsentState
AllowedCompanionRoles[]
DisallowedContexts[]
DoesNotBypassInjury true
DoesNotBypassLeash true
DoesNotBypassCaveRisk true
```

### 7.3 PartnerFarmHelperRule

```text
RuleId
NpcId
AllowedHelperTasks[]
DailyHelperBudgetCost
WeeklyHelperBudgetCost
RequiresFarmVisit
RequiresToolOrStation optional
OutputPolicy
CanAutoRepeat false
```

### 7.4 PartnerHelperBudget

```text
GlobalDailyBudget
GlobalWeeklyBudget
UsedDailyBudget
UsedWeeklyBudget
PartnerIdsUsingBudget[]
PolyculeCap
HelperStackingPolicy
```

### 7.5 PartnerHelperAssignment

```text
AssignmentId
PartnerNpcId
AssignmentType: LightFarmHelp | SocialVisit | CompanionUnlockQuest | CaveCompanionInvite
BudgetCost
Day
Duration
ResultPolicy
```

---

## 8. Bridge rules

```text
PartnerCompanionEligible:
  can request companion unlock path if companion profile exists.

PartnerFarmHelperEligible:
  can request limited farm helper path.

NPC not combatant:
  cannot become cave companion just because partner.

Polycule:
  up to 3 partners, but helper budget global and cave active companion cap remains 1.

Spouse/partner:
  does not bypass companion injury/recovery.
```

---

## 9. Helper tasks

```text
Allowed examples:
  water few crops;
  feed animals future;
  deliver small item;
  prepare simple food future;
  repair minor fence future;
  social visit;
  reminder/forecast hint;
  low-yield farm help.

Not allowed:
  full-field automation;
  infinite processing;
  auto-sell;
  combat power boost without companion system;
  cave party size increase;
  pet care runtime without pet spec.
```

---

## 10. Criteria

```text
Partner helper/companion bridge contracts exist.
Partner does not bypass companion eligibility.
Cave cap remains 1.
Global helper budget prevents stacking.
No pet runtime.
No romance/casamento scenes.
Tests cover partner eligible, noncombat partner blocked for cave, farm helper budget, polycule stacking, injury/leash preserved, cave cap 1 and no auto-sell.
```

# /speckit.plan

## 11. Arquitetura alvo

```text
Assets/_Game/Scripts/Social/Partners/PartnerHelperEligibility.cs
Assets/_Game/Scripts/Social/Partners/PartnerCompanionBridgeRule.cs
Assets/_Game/Scripts/Social/Partners/PartnerFarmHelperRule.cs
Assets/_Game/Scripts/Social/Partners/PartnerHelperBudget.cs
Assets/_Game/Scripts/Social/Partners/PartnerHelperAssignment.cs
Assets/_Game/Scripts/Social/Partners/PartnerHelperBridgeService.cs
Assets/_Game/Scripts/Social/Partners/PartnerHelperAntiExploitValidator.cs
Assets/_Game/Tests/EditMode/Social/PartnerHelperCompanionBridgeTests.cs
```

Consolidar existentes se houver.

## 12. Arquivos permitidos

```text
Assets/_Game/Scripts/Social/**
Assets/_Game/Scripts/Companions/**
Assets/_Game/Scripts/Farm/**
Assets/_Game/Scripts/Quests/**
Assets/_Game/Scripts/Editor/Validation/**
Assets/_Game/Tests/EditMode/Social/**
docs/validation/17_spec_partner_helper_companion_bridge_future_runtime_execution_report.md
```

## 13. Arquivos proibidos

```text
Packages/**
ProjectSettings/**
Assets/**/*.unity
Assets/**/*.prefab
Assets/**/*.asset
Assets/_Game/Scripts/Pets/**
docs/specs/SPEC_EXECUTION_ORDER.md
docs/specs/implementados/**
docs/refinements/implementados/**
docs/project/CURRENT_STATE.md
PROJECT_LOG.md
```

# /speckit.tasks

## 14. Tasks

- [ ] T001 — Ler fontes.
- [ ] T002 — Auditar social/companion/farm bridge references.
- [ ] T003 — Consolidar bridge/budget contracts.
- [ ] T004 — Implementar validators.
- [ ] T005 — Criar tests.
- [ ] T006 — Rodar validações.
- [ ] T007 — Criar report.

## Source Map Compliance

### Global sources read

- docs/design/SPEC_SOURCE_MAP.md
- docs/design/SPECIFICATION_PROCESS.md
- docs/design/lore/VAALARA_GAME_CANON_DIRECTION_v1.0.md
- docs/specs/SPEC_IMPLEMENTABLE_TEMPLATE.md
- docs/specs/SPEC_WAVE_EXECUTION_PROTOCOL.md
- docs/specs/SPEC_VALIDATION_MATRIX_MASTER.md
- docs/specs/SPEC_EXISTING_IMPLEMENTATION_AUDIT.md
- docs/project/CURRENT_STATE.md

### Domain directions read

- docs/design/gameplay/social/SOCIAL_RELATIONSHIP_ROMANCE_DIRECTION.md
- docs/design/gameplay/city/CITY_DESIGN_DIRECTION_v1.2.md
- docs/design/gameplay/city/CITY_NPC_ROSTER_SERVICES_DIRECTION_v1.1.md
- docs/design/gameplay/city/CITY_LAYOUT_BUILDINGS_SCHEDULE_DIRECTION.md
- docs/design/gameplay/farm/FARM_DESIGN_DIRECTION_v1.3.md
- docs/design/gameplay/farm/FARM_LAYOUT_SCALE_BUILDINGS_DIRECTION.md
- docs/design/gameplay/companions/COMPANIONS_DIRECTION.md
- docs/design/gameplay/pets/PETS_DIRECTION.md
- docs/design/gameplay/loot_crafting_economy/LOOT_CRAFTING_ECONOMY_DIRECTION.md
- docs/design/gameplay/loot_crafting_economy/ECONOMY_PRICING_STOCK_REFRESH_DIRECTION.md
- docs/design/gameplay/quests/QUEST_OBJECTIVE_EVENT_SYSTEM_DIRECTION.md
- docs/design/gameplay/quests/QUESTS_MAIN_LORE_DIRECTION.md
- docs/design/gameplay/quests/QUESTS_MAIN_PROGRESSION_REFINEMENT_DIRECTION.md
- docs/design/gameplay/save_load/SAVE_LOAD_FULL_STATE_DIRECTION.md
- docs/design/gameplay/ui_ux/UI_UX_FULL_GAMEPLAY_DIRECTION.md
- docs/design/gameplay/ui_ux/UI_UX_MENU_SCREEN_FLOWS_DIRECTION.md
- docs/design/gameplay/world/SEASONS_CALENDAR_WEATHER_LUNAR_DIRECTION.md
- docs/design/gameplay/cave/CAVE_DESIGN_DIRECTION.md
- docs/design/gameplay/cave/CAVE_MONSTER_ROSTER_DIRECTION.md
- docs/design/gameplay/bestiary/BESTIARY_KNOWLEDGE_DISCOVERY_DIRECTION.md

### Required interpretation

```text
Esta spec é future/mapped.
Ela deriva principalmente de SOCIAL_RELATIONSHIP_ROMANCE_DIRECTION.
Ela não implementa romance cutscenes, cerimônias, dating scene, intimidade, children/family system, jealousy amplo, conteúdo explícito, pet runtime ou companion AI.
Ela trata romance/casamento/poliamor apenas como estados mecânicos futuros, opcionais, consentidos e não obrigatórios para o core loop.
NPCs com TooYoungOrNarrativelyBlocked não podem ter rota ambígua, flerte, dating, presente romântico ou evento de romance.
Quando houver conflito com roster de NPCs, companions, pets, economy, quest, city schedule, UI ou save directions, o executor deve parar e registrar CONFLICT.
```

---

## Direction / Refinement Coverage

### Covered from directions

- Parceiros românticos/cônjuges podem virar companions futuros quando elegíveis.
- Romance/casamento pode desbloquear rota de companion, mas companion unlock ainda exige perfil e quest apropriada.
- Ser parceiro não ignora balance de companion, injury/recovery, leash, cave risk ou limites de combate.
- NPC não combatente pode ser farm helper sem virar cave companion.
- Mesmo com até 3 parceiros, baseline de caverna continua 1 companion ativo por run.
- Parceiros podem ajudar na fazenda futuramente, mas ajuda não substitui jogador, companions, pets, skill tree, ferramentas ou economia.

### Deferred / future from directions

- Companion AI.
- Farm job execution.
- Partner moving to farm visuals.
- Romance/casamento scenes.
- Pet runtime.
- Children/family system.

### Explicitly not redefined here

- Companion eligibility internals.
- Farm automation core.
- Cave companion AI.
- Relationship state transitions.
- NPC roster.

---

## 23A. Execution Readiness Matrix

| Área | Pergunta obrigatória | Evidência esperada | Status se faltar |
|---|---|---|---|
| Fonte canônica | Executor leu social, city roster, companion, pet, economy, quest, save e UI directions? | Lista no report. | PARTIAL |
| Estado real do repo | Sistemas existentes relacionados a partner helper/companion bridge foram auditados antes de criar novos? | Comandos `rg` e achados. | PARTIAL |
| Não duplicação | Existe sistema equivalente já implementado/parcial? | REUSE/HARDEN/CREATE/DEFER. | BLOCKED se duplicar |
| Opcionalidade | Social/romance/casamento não é obrigatório para main quest, final bom, cidade, caverna, fazenda ou build. | Tests/checklist. | BLOCKED se violar |
| Consentimento/limites | Estados de romance/poliamor respeitam eligibility, blocked states, consent flags e limite global. | Tests/checklist. | PARTIAL |
| Menores/bloqueados | TooYoungOrNarrativelyBlocked não tem flerte, dating, romance gift, ceremony ou ambiguidades. | Tests/checklist. | BLOCKED se violar |
| Anti-exploit | Presentes/partner/helper não viram gold, stamina, combat power ou farm automation superior. | Tests/checklist. | PARTIAL |
| Separação | Pet bond, companion bond, relationship e reputation não são misturados. | Tests/checklist. | PARTIAL |
| Save/load | Houve alteração de schema? | Declaração NO ou STOP se migration necessária. | BLOCKED se alterar sem migration |
| UI/PlayMode | Há fluxo visual/gameplay integrado? | Cenário final deferido documentado. | BUILD_VALIDATED no máximo se ausente |
| Testes | Lógica determinística nova tem EditMode tests quando praticável? | Test list. | PARTIAL |
| Report | Execution report criado? | `docs/validation/17_spec_partner_helper_companion_bridge_future_runtime_execution_report.md`. | PARTIAL |

---

## 23B. Local Audit Checklist

Antes de alterar qualquer arquivo, Claude Code/Codex deve rodar e registrar no execution report:

```bash
rg -n "PartnerHelper|PartnerCompanion|PartnerFarmHelper|SpouseHelper|Polycule|CompanionEligibility|CaveCompanion|FarmHelperBudget" Assets/_Game/Scripts docs/design docs/specs
rg -n "Relationship|Friendship|Trust|Affection|Romance|Dating|Committed|Married|Polycule|Gift|GiftPreference|SocialMemory|PartnerHelper|PartnerCompanion|TooYoung|NarrativelyBlocked|PetBond|CompanionBond|Jealousy|Divorce|Children" Assets/_Game/Scripts docs/design docs/specs
rg -n "TODO|FIXME|HACK|PARTIAL|DEFERRED|BUILD_VALIDATED|ACCEPTED" docs/specs docs/validation docs/IMPLEMENTATION_STATUS.md docs/project/CURRENT_STATE.md
```

Classificar achados:

```text
EXISTING_CANONICAL
EXISTING_PARTIAL
MISSING_SAFE_TO_CREATE
MISSING_BUT_DEFER
CONFLICT
```

---

## 23C. Functional Acceptance Scenarios

### Scenario 1 — Happy path

```text
Given NPC elegível e estado social válido
When o sistema desta spec processa relação, presente, diálogo, visita, quest ou helper
Then ele aplica apenas efeito permitido, limitado, opcional e rastreável
And não mistura pet/companion/reputation
And não força romance/casamento/poliamor no core loop.
```

### Scenario 2 — Existing partial implementation

```text
Given já existe implementação parcial no repo
When a execução audita o sistema
Then ela escolhe HARDEN_EXISTING em vez de recriar do zero
And registra divergências do direction
And altera apenas o menor conjunto seguro de arquivos.
```

### Scenario 3 — Blocked or protected NPC

```text
Given NPC com UnavailableForRomance, MarriedToNpc, TooYoungOrNarrativelyBlocked, PolyBlocked ou bloqueio narrativo
When o jogador tenta ação romântica/poliamorosa/casamento/partner helper incompatível
Then o sistema bloqueia com razão clara e segura
And amizade, respeito, serviços e quests não-românticas continuam possíveis quando apropriado.
```

### Scenario 4 — Anti-exploit

```text
Given presente, visita, partner helper, companion unlock ou benefício social
When o efeito é calculado
Then há limite diário/semanal/orçamento global/cooldown/eligibility
And não gera ouro, stamina, HP/MP, combat power ou farm automation superior aos sistemas dedicados.
```

### Scenario 5 — Final human validation deferred

```text
Given o fluxo exige inspeção visual/gameplay de social UI, gift reaction, visit, personal quest or partner helper UI
When a implementação técnica terminar
Then o report registra cenário final em docs/validation/FINAL_HUMAN_VALIDATION_BY_WAVE.md
And não pede validação humana imediata por spec.
```

---

## 23D. Edge Cases and Failure Modes

A execução deve cobrir ou registrar risco residual para:

- Marriage auto-unlocks combat companion.
- Three partners enter cave together.
- Partner helper generates infinite output.
- Partner helper auto-sells.
- Partner bypasses injury/recovery.
- Partner bypasses leash/cave risk.
- Romance becomes best power path.
- Pet treated as partner helper.

---

## 23E. Minimum Execution Report Template

```md
# Execution Report — Partner Helper Companion Bridge Future Runtime

## Summary
- Spec:
- Branch:
- Executor:
- Date:
- Final status:

## Sources read
- ...

## Local audit
- Commands executed:
- Existing systems found:
- Existing partial systems found:
- Missing systems:
- Conflicts:

## Social compliance
- Optional social/romance:
- No explicit/intimate content:
- No blocked NPC route:
- Consent/eligibility checked:
- Max partner cap respected:
- No pet bond mixing:
- No companion bond mixing:
- No economy/combat/farm exploit:
- Save/load safe:
- UI not source of truth:

## Implementation decision
- REUSE_EXISTING / HARDEN_EXISTING / CREATE_MINIMAL / DEFER
- Justification:

## Files changed
- ...

## Functional evidence
- Happy path:
- Existing partial:
- Blocked/protected NPC:
- Anti-exploit:
- Save/load:
- UI/final scenario:

## Validation
- Docs validation:
- C# build:
- Unity compile:
- EditMode tests:
- PlayMode automated:
- Final human scenario:

## Testing Quality Gate
- Changed deterministic logic:
- Requires EditMode tests:
- Requires PlayMode automated or final human scenario:
- Requires regression test:
- Human validation timing:
- Minimum validation evidence for ACCEPTED:

## Residual risks
- ...

## Next specs impacted
- ...
```

---

## 23F. Stop Conditions

Parar a execução e registrar `BLOCKED` se ocorrer qualquer um destes casos:

```text
1. A implementação exigir alterar Packages/ ou ProjectSettings/.
2. A implementação exigir scene/prefab/tilemap/asset wiring fora do escopo.
3. A implementação alterar save schema sem migration spec.
4. A implementação criar conteúdo íntimo/explícito, cutscene romântica ou dating scene.
5. A implementação permitir rota romântica para TooYoungOrNarrativelyBlocked.
6. A implementação tornar romance/casamento/poliamor obrigatório para main quest, final, poder ou progresso essencial.
7. A implementação criar exploit de ouro, stamina, HP/MP, combat power, farm automation ou companion power via social.
8. A implementação misturar pet bond, companion bond, reputation ou quest flags genéricas dentro de Relationship.
9. A implementação criar jealousy punitivo amplo, children/family system, divorce/separation ou cerimônia visual.
10. Não for possível decidir se sistema existente é canônico ou obsoleto.
```



---

## 25. Validações obrigatórias

Docs:

```powershell
.\tools\docs\validate_docs.ps1
```

Busca local mínima:

```bash
rg -n "Relationship|Friendship|Trust|Affection|Romance|Dating|Committed|Married|Polycule|Gift|GiftPreference|SocialMemory|PartnerHelper|PartnerCompanion" Assets/_Game/Scripts docs/design docs/specs
```

C# runtime/editor quando houver alteração C#:

```powershell
dotnet build .\Assembly-CSharp.csproj --no-restore
dotnet build .\Assembly-CSharp-Editor.csproj --no-restore
```

Unity compile quando houver alteração Unity C#:

```powershell
.\tools\unity\RunUnityCompileValidation.ps1 -ProjectPath "." -LogFile ".\Logs\unity-compile-validation.log"
.\tools\unity\ScanUnityLogs.ps1 -LogFile ".\Logs\unity-compile-validation.log"
```

EditMode tests quando lógica determinística for criada/alterada:

```text
Unity Test Runner — EditMode, ou comando local equivalente disponível no repo.
```

PlayMode/final human validation:

```text
Não pedir validação humana por spec.
Quando houver cenário visual/gameplay de social UI, gifts, visit, personal quest, partner helper ou companion bridge, registrar em execution report e vincular a docs/validation/FINAL_HUMAN_VALIDATION_BY_WAVE.md.
```

---

## 26. Testing Quality Gate

- Changed deterministic logic: YES, eligibility/budget/cap/bridge validation logic is deterministic.
- Requires EditMode tests: YES for eligibility/noncombat/cave-cap/budget/injury/leash/no-autosell tests.
- Requires PlayMode automated or final human scenario: YES, DEFERRED for partner helper UI/flow validation.
- Requires regression test: YES if fixing existing partner helper bridge bug; otherwise NO.
- Human validation timing: DEFERRED_TO_FINAL_VALIDATION se houver UI/gameplay integrado; caso contrário NOT REQUIRED.
- Minimum validation evidence for ACCEPTED: docs validation PASS; C# build PASS if C# changed; EditMode tests PASS or NOT RUN justified; partner helper bounded and optional.

---

## 27. Definition of Done

```text
Spec executada sem alterar arquivos proibidos.
Contratos/data/runtime implementados apenas dentro do escopo.
Execution report criado em docs/validation/17_spec_partner_helper_companion_bridge_future_runtime_execution_report.md.
Fonte/direction coverage preservado.
Validações obrigatórias PASS ou NOT RUN com motivo, impacto e mitigação.
Sem promoção indevida para ACCEPTED apenas por compile.
```

---

## 28. Anti-regressão

```text
Não implementar conteúdo íntimo/explícito.
Não criar cutscene romântica/dating scene.
Não permitir rota ambígua para NPC bloqueado/idade/narrativa.
Não tornar romance/casamento/poliamor obrigatório.
Não misturar relationship com pet bond/companion bond/reputation.
Não gerar exploit social de economia, combate, stamina ou farm.
Não criar pet runtime.
Não criar companion AI.
Não salvar UI state como gameplay state.
Não pedir human test por spec.
Não executar runtime em massa antes da 01Q ou exceção humana explícita.
Não alterar SPEC_EXECUTION_ORDER.md.
```

---

## 29. Notas para execução posterior

Esta spec é future/mapped. Deve ser executada apenas quando City/NPC, Quest, Save, UI, Economy e Companion foundations estiverem estáveis ou quando houver decisão humana explícita de antecipar Social/Relationship.
