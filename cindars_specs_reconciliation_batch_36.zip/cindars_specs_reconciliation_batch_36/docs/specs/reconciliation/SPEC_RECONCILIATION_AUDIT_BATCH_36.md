# Cindar's Hope — Spec Reconciliation Audit Batch 36

> Data: 2026-06-07  
> Repo alvo: `rafa210587/cindars_hope`  
> Branch alvo: `dev`  
> Tipo: auditoria/reconciliação documental  
> Patches de código: NÃO  
> Specs novas: NÃO  

## 1. Resultado

```text
Roadmap macro estimado: ~137 specs totais
Specs únicas encontradas nos zips locais disponíveis: 137
Duplicatas por filename encontradas: 28
Specs com marker estrutural faltante: 20
```

Classificação local:

```text
core_or_runtime / hardening: 90
future/mapped: 43
future/mapped/HOLD: 4
```

## 2. Achado principal

O arquivo atual `docs/specs/SPEC_REGISTRY_TO_IMPLEMENT.md` ainda está desatualizado para o novo modelo. Ele aponta a pasta `docs/specs/a_implementar/` como fonte única, mas lista apenas 01Q e specs antigas/residuais, não as specs geradas nos batches.

## 3. Implicação

Não devemos iniciar implementação em massa ainda. Antes disso, é necessário:

```text
1. Copiar os zips/batches de specs para `docs/specs/a_implementar/`.
2. Atualizar ou regenerar `SPEC_REGISTRY_TO_IMPLEMENT.md`.
3. Inserir seção complementar no `SPEC_EXECUTION_ORDER.md`.
4. Marcar specs future/HOLD como não executáveis sem aprovação.
5. Remover/arquivar specs antigas que ficaram substituídas, somente após auditoria local.
6. Rodar validação documental.
```

## 4. O que este batch entrega

```text
docs/specs/reconciliation/SPEC_RECONCILIATION_AUDIT_BATCH_36.md
docs/specs/reconciliation/GENERATED_SPECS_MANIFEST_BATCH_01_35.json
docs/patches/SPEC_REGISTRY_TO_IMPLEMENT_DRAFT.md
docs/patches/SPEC_EXECUTION_ORDER_APPEND_DRAFT.md
docs/prompts/PROMPT_CLAUDE_CODE_APPLY_RECONCILIATION_PATCHES.md
docs/prompts/PROMPT_CODEX_VALIDATE_RECONCILIATION.md
```

## 5. Bloqueios antes de implementar specs

```text
- 01Q precisa existir e estar executada antes de Waves runtime em massa.
- Registry precisa listar as specs novas.
- Future/HOLD precisa estar bloqueado no registry.
- Pets batch 34 precisa seguir HOLD/BLOCKED_SCOPE.
- Não promover nada para implementados sem execution report.
```

## 6. Resultado recomendado

Aplicar primeiro apenas patches documentais de registry/reconciliation. Depois rodar docs validation. Só então escolher a primeira spec runtime/hardening para execução.
