# SPEC_EXECUTION_ORDER — DRAFT complementar pós-geração

> Este draft não deve apagar o histórico atual. Deve ser usado para inserir uma seção nova no `SPEC_EXECUTION_ORDER.md` ou gerar um registry dedicado para as specs novas.

## Estado de reconciliação

```text
Specs únicas encontradas nos zips locais: 137
Core/runtime/hardening aproximadas: 90
Future/mapped: 43
Future/mapped/HOLD: 4
Roadmap macro esperado: ~137 specs totais.
```

## Ordem macro preservada

```text
00 -> 01/01Q -> 02 -> 03 -> 04 -> 05 -> 06 -> 07 -> 08 -> 09 -> 10 -> 11 -> future waves 12+
Nenhuma spec runtime das Waves 02+ deve ser executada em massa antes da 01Q ou exceção humana explícita documentada.
```

## Batches disponíveis

| Batch | Specs no zip local | Observação |
|---:|---:|---|
| 1 | 4 |  |
| 1 | 20 |  |
| 2 | 4 |  |
| 3 | 4 |  |
| 4 | 4 |  |
| 5 | 4 |  |
| 6 | 4 |  |
| 6 | 8 |  |
| 7 | 4 |  |
| 8 | 4 |  |
| 9 | 4 |  |
| 10 | 4 |  |
| 11 | 4 |  |
| 12 | 4 |  |
| 13 | 4 |  |
| 14 | 4 |  |
| 15 | 4 |  |
| 16 | 4 |  |
| 17 | 4 |  |
| 18 | 4 |  |
| 19 | 4 |  |
| 20 | 4 |  |
| 21 | 4 |  |
| 22 | 4 |  |
| 23 | 2 |  |
| 24 | 4 |  |
| 25 | 4 |  |
| 26 | 4 |  |
| 27 | 4 |  |
| 28 | 4 |  |
| 29 | 4 |  |
| 30 | 4 |  |
| 31 | 4 |  |
| 32 | 4 |  |
| 33 | 4 |  |
| 34 | 4 | pets HOLD |
| 35 | 3 | fechamento final |