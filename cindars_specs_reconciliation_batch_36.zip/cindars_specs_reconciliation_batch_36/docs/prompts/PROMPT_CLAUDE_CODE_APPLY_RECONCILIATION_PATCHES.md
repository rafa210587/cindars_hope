# PROMPT — Claude Code: aplicar reconciliação documental das specs geradas

Estamos no repo `rafa210587/cindars_hope`, branch `dev`.

Objetivo: aplicar APENAS reconciliação documental para as specs geradas em batches. Não implementar código Unity.

## Regras obrigatórias

1. Não alterar `Assets/`, `Packages/`, `ProjectSettings/`, scenes, prefabs, ScriptableObject assets, audio, sprites, localization.
2. Não mover specs para `docs/specs/implementados/`.
3. Não promover status para ACCEPTED.
4. Não executar specs runtime.
5. Não executar pets. Specs de pets ficam HOLD/BLOCKED_SCOPE.
6. Não recriar pasta raiz `specs/`.
7. Fonte única de specs futuras continua `docs/specs/a_implementar/`.

## Arquivos que você deve ler antes

- `docs/design/SPEC_SOURCE_MAP.md`
- `docs/specs/SPEC_GENERATION_ROADMAP_MASTER.md`
- `docs/specs/SPEC_REGISTRY_TO_IMPLEMENT.md`
- `docs/specs/SPEC_REGISTRY_IMPLEMENTED.md`
- `docs/specs/SPEC_EXECUTION_ORDER.md`
- `docs/specs/SPEC_WAVE_EXECUTION_PROTOCOL.md`
- `docs/specs/SPEC_VALIDATION_MATRIX_MASTER.md`
- `docs/validation/FINAL_HUMAN_VALIDATION_BY_WAVE.md`

## Arquivos vindos deste pacote

Copiar ou comparar:

- `docs/specs/reconciliation/SPEC_RECONCILIATION_AUDIT_BATCH_36.md`
- `docs/specs/reconciliation/GENERATED_SPECS_MANIFEST_BATCH_01_35.json`
- `docs/patches/SPEC_REGISTRY_TO_IMPLEMENT_DRAFT.md`
- `docs/patches/SPEC_EXECUTION_ORDER_APPEND_DRAFT.md`

## Tarefas

1. Verificar se todos os arquivos `docs/specs/a_implementar/*.md` dos batches já existem no repo local.
2. Se algum batch/spec não existir, listar no relatório e não inventar conteúdo.
3. Atualizar `docs/specs/SPEC_REGISTRY_TO_IMPLEMENT.md` para incluir as specs novas, preservando o histórico existente.
4. Adicionar seção de reconciliação ao `docs/specs/SPEC_EXECUTION_ORDER.md`, sem apagar histórico.
5. Criar `docs/specs/reconciliation/SPEC_RECONCILIATION_AUDIT_BATCH_36.md`.
6. Criar `docs/specs/reconciliation/GENERATED_SPECS_MANIFEST_BATCH_01_35.json`.
7. Marcar future/mapped e HOLD de forma explícita no registry.
8. Marcar pets como HOLD/BLOCKED_SCOPE.
9. Rodar validação documental.

## Comandos mínimos

```bash
rg -n "Future mapped|HOLD|BLOCKED_SCOPE|/speckit.specify|Testing Quality Gate|Source Map Compliance" docs/specs/a_implementar docs/specs/reconciliation
rg -n "SPEC_REGISTRY_TO_IMPLEMENT|SPEC_EXECUTION_ORDER|SPEC_GENERATION_ROADMAP_MASTER" docs/specs
```

Windows PowerShell:

```powershell
.\tools\docs\validate_docs.ps1
```

## Entrega esperada

Criar relatório:

`docs/validation/SPEC_RECONCILIATION_BATCH_36_EXECUTION_REPORT.md`

Com:

- arquivos alterados;
- specs encontradas;
- specs ausentes;
- duplicatas;
- futures;
- HOLDs;
- validação documental;
- pendências;
- decisão se podemos começar execução da primeira spec runtime/hardening.

## Stop conditions

Parar e registrar BLOCKED se:

- algum registry exigir promover spec sem evidência;
- houver tentativa de executar runtime;
- houver tentativa de alterar código Unity;
- specs geradas não estiverem presentes em `docs/specs/a_implementar/`;
- pets não estiverem marcados como HOLD/BLOCKED_SCOPE.
