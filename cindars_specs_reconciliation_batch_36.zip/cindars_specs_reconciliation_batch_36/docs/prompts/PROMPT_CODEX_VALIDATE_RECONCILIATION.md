# PROMPT — Codex: validar reconciliação das specs geradas

Você está validando documentação no repo `rafa210587/cindars_hope`, branch `dev`.

Não implemente gameplay. Não altere código Unity.

## Objetivo

Validar se a reconciliação documental pós-geração das specs está correta.

## Leia

- `docs/specs/SPEC_GENERATION_ROADMAP_MASTER.md`
- `docs/specs/SPEC_REGISTRY_TO_IMPLEMENT.md`
- `docs/specs/SPEC_REGISTRY_IMPLEMENTED.md`
- `docs/specs/SPEC_EXECUTION_ORDER.md`
- `docs/specs/reconciliation/SPEC_RECONCILIATION_AUDIT_BATCH_36.md`
- `docs/specs/reconciliation/GENERATED_SPECS_MANIFEST_BATCH_01_35.json`
- `docs/design/SPEC_SOURCE_MAP.md`

## Validar

1. Todas as specs listadas no manifest existem em `docs/specs/a_implementar/`.
2. Nenhuma spec future/HOLD foi marcada como núcleo executável imediato.
3. Pets estão HOLD/BLOCKED_SCOPE.
4. `SPEC_REGISTRY_TO_IMPLEMENT.md` preserva histórico e inclui specs novas.
5. `SPEC_EXECUTION_ORDER.md` preserva histórico e inclui aviso de execução pós-01Q.
6. Não há alteração em `Assets/`, `Packages/`, `ProjectSettings/`.
7. Não há promoção indevida para `implementados/`.
8. Não há duplicatas por filename.
9. Todas as specs novas têm:
   - `/speckit.specify`
   - `/speckit.plan`
   - `/speckit.tasks`
   - `Testing Quality Gate`
   - `Source Map Compliance`
   - `Stop Conditions`

## Comandos sugeridos

```bash
find docs/specs/a_implementar -maxdepth 1 -name "*.md" | sort > /tmp/a_implementar_specs.txt
python - <<'PY'
import json, pathlib
m=json.load(open('docs/specs/reconciliation/GENERATED_SPECS_MANIFEST_BATCH_01_35.json', encoding='utf-8'))
missing=[]
for s in m['specs']:
    p=pathlib.Path('docs/specs/a_implementar')/s['file']
    if not p.exists():
        missing.append(str(p))
print('missing', len(missing))
for x in missing[:100]:
    print(x)
PY
rg -n "HOLD|BLOCKED_SCOPE|Future mapped|01Q|Testing Quality Gate" docs/specs
```

## Saída esperada

Criar ou atualizar:

`docs/validation/SPEC_RECONCILIATION_BATCH_36_CODEX_VALIDATION.md`

Com status:

- PASS
- PASS_WITH_WARNINGS
- BLOCKED

Não marcar PASS se specs estiverem ausentes do repo local.
