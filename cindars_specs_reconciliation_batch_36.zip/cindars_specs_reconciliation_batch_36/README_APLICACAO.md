# cindars_specs_reconciliation_batch_36

Este pacote não contém specs novas de gameplay. Ele contém reconciliação documental pós-geração.

## Conteúdo

```text
docs/specs/reconciliation/SPEC_RECONCILIATION_AUDIT_BATCH_36.md
docs/specs/reconciliation/GENERATED_SPECS_MANIFEST_BATCH_01_35.json
docs/patches/SPEC_REGISTRY_TO_IMPLEMENT_DRAFT.md
docs/patches/SPEC_EXECUTION_ORDER_APPEND_DRAFT.md
docs/prompts/PROMPT_CLAUDE_CODE_APPLY_RECONCILIATION_PATCHES.md
docs/prompts/PROMPT_CODEX_VALIDATE_RECONCILIATION.md
```

## Resultado local

```text
Specs únicas encontradas nos zips locais disponíveis: 137
Duplicatas: 28
Specs com markers faltantes: 20
```

## Uso

1. Copie este pacote para o repo.
2. Passe o prompt de aplicação para Claude Code.
3. Passe o prompt de validação para Codex.
4. Não implemente runtime ainda.
